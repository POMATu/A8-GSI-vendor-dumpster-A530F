#!/sbin/sh

umount /vendor
mount /vendor

exit 0
